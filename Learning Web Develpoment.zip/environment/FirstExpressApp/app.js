var express = require("express");
var app  = express();

// "/" => "Hi There"

app.get("/", function(req,res){
res.send("Hi There");    
});

// "/Bye" => "Goodbye"
app.get("/bye",function(req,res){
    res.send("GOODBYE!!");
});

 // "/dogs" => "MEOW!"
 app.get("/dogs",function(req, res) {
     res.send("meow");
 });

//Tell Express to listen for requests(start server)
app.listen(process.env.PORT,process.env.IP,function(){
    console.log("Server Has Started");
});
