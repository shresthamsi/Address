var express =require("express");
var app = express();

var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: false }));

var friends=["RINA","MINA","SHEETAL","ADI","PALAK"];

app.set("view engine","ejs");

app.get("/",function(req,res){
    res.render("home");
});

app.get("/friends",function(req,res){
    res.render("friends",{friendVar : friends});
    console.log("worked!");
});

app.post("/addfriend",function(req,res){
    // res.send("You are getting this msg from the post route");
    friends.push(req.body.newfriend);
    
    res.redirect("/friends");
});

app.listen(process.env.PORT,process.env.IP,function(){
    console.log("Server is listening");
});