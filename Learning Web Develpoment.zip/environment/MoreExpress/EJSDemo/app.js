var express = require("express");
var app = express();

app.use(express.static("public"));
app.set("view engine","ejs");

app.get("/", function(req,res){
    res.render("home");
});

app.get("/fallinlovewith/:thing", function(req,res){
    var thing = req.params.thing;
    res.render("love",{thingVar : thing});
});

app.get("/posts",function(req, res) {
    var posts =[
        {title:"Book1" , author : "Shrestha1"},
        {title:"Book2" , author : "Shrestha2"},
        {title:"Book3" , author : "Shrestha3"}
        ]
    res.render("posts",{postVar:posts});
})
app.listen(process.env.PORT,process.env.IP,function(){
    console.log("Server is listening");
});

