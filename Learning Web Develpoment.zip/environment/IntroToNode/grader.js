function average(sc){
    var sum=0;
    for(var i=0;i<sc.length;i++){
        sum = sum + sc[i];
    }
    var avg = sum/sc.length;
    return Math.round(avg);
}

 var scores = [90,98,89,100,100,86,94];
var avg1 = average(scores);

var scores2 = [40,65,77,82,80,54,73,63,95,49];
var avg2 = average(scores2);
console.log(avg1);
console.log(avg2);