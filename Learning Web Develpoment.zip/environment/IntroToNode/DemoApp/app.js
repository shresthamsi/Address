var something = require("cat-me");
var knockknock = require('knock-knock-jokes')

console.log(something());
console.log(knockknock()) ;