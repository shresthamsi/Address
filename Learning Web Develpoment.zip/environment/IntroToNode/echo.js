function echo(string, num){
    for(var i=0;i<num;i++){
    console.log(string);
    }
}

echo("Echo!!!",10);
echo("Tater Tots",3);